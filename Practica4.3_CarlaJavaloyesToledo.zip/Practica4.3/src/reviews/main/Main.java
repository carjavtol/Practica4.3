/*
Carla Javaloyes Toledo
*/

package reviews.main;

import reviews.data.Business;
import reviews.data.Review;
import reviews.data.User;

import java.awt.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Management m = new Management();
        String login, password;
        User user = null;
        m.initialize();

        do{
            System.out.println("Login:");
            login = sc.nextLine();

            System.out.println("Password:");
            password = sc.nextLine();
        }
        while(m.userLogin(login, password) == null);

        Menu(user);

    }

    public static void Menu(User user){
        Scanner sc = new Scanner(System.in);
        Management m = new Management();
        Management [] managements = new Management[20];
        int option, optionBusiness = 0;

        do{
            System.out.println("Menu:");
            System.out.println("1. My reviews");
            System.out.println("2. Business list");
            System.out.println("3. Top rated business");
            System.out.println("4. Edit my review");
            System.out.println("5. Quit");
            System.out.println("Select an option:");
            option = sc.nextInt();

            switch (option){
                case 1:
                    m.showReviews(user);
                    break;
                case 2:
                    m.sortBusinessesByName();
                    break;
                case 3:
                    m.sortBusinessesByRating(optionBusiness);
                    break;
                case 4:
                    EditMyReview (m, user);
                    break;
                case 5:
                    System.out.println("Bye!");
                    break;
                default:
                    System.out.println("Mistake, wrong choice");
                    break;
            }
        }
        while(option < 1 || option > 5);
    }

    static void EditMyReview (Management m, User user){

        Scanner sc = new Scanner(System.in);
        String businessName, comment;
        int rating;
        System.out.println("Choose a business:");
        businessName = sc.nextLine();
        Business b = m.findBusiness(businessName);
        Review r = m.findReview(user, b);

        if (b != null && r != null){

            System.out.println(b);
            System.out.println(r);
            System.out.println("Comment:");
            comment = sc.nextLine();
            System.out.println("Rating:");
            rating = sc.nextInt();
            m.changeReview(r, comment, rating);
        }
    }
}
