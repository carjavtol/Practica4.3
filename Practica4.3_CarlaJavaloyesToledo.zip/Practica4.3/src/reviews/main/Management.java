package reviews.main;

import reviews.data.*;
import java.util.Arrays;
import java.util.Scanner;


public class Management {
    protected User[] users = new User [10];
    protected Business[] businesses = new Business[2];
    protected Review [] reviews = new Review[2];

    public void initialize(){
        users[0] = new User ("carla", "1234");
        users[1] = new User ("javaloyes", "1234");
        users[2] = new User ("toledo", "1234");
        users[3] = new User ("cjt", "1234");
        users[4] = new User ("carjavtol", "1234");
        users[5] = new User ("cajato", "1234");
        users[6] = new User ("javaloyes toledo", "1234");
        users[7] = new User ("toledo javaloyes", "1234");
        users[8] = new User ("carla javaloyes toledo", "1234");
        users[9] = new User ("carla javaloyes", "1234");

        reviews[0] = new Review(users[0], "comment1", 4);
        reviews[1] = new Review(users[7], "comment2", 5);

        businesses[0] = new Hairdresser("hairdresser", "location hairdresser", true,
                new Review[]{reviews[0]});
        businesses[0] = new Restaurant("restaurant", "location restaurant", "italian",
                new Review[]{reviews[1]});
    }

    public void showReviews(User user) {
        for (int i=0; i < reviews.length; i++) {
            if (user.equals(reviews[i].getAssociatedUser().getLogin())) {
                System.out.println(reviews[i]);
            }
        }
    }

    public void sortBusinessesByName(){
        Arrays.sort(businesses);
        System.out.println(Arrays.toString(businesses));
    }

    public void sortBusinessesByRating(int type) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Select an option:");
        System.out.println("1. Restaurants, 2.Hairdressers, 3.Garages:");
        type = sc.nextInt();

        for (int i =0; i< businesses.length; i++) {
            if (type == 1) {
                if (businesses[i].getClass() == Restaurant.class) {
                    System.out.println(businesses[i].toString());
                }
            }
            else if (type == 2) {
                if (businesses[i].getClass() == Hairdresser.class) {
                    System.out.println(businesses[i].toString());
                }
            }

            else if (type == 3) {
                if (businesses[i].getClass() == Garage.class) {
                    System.out.println(businesses[i].toString());
                }
            }
        }
    }

    public User userLogin(String login, String password) {

        for (int i = 0; i < users.length; i++) {
            if (login.equals(users[i].getLogin()) && password.equals(users[i].getPassword())) {
                return users[i];
            }
        }
        return null;
    }

    public Business findBusiness(String businessName) {
        for (int i=0; i < businesses.length; i++) {
            if (businessName.toUpperCase().equals(businesses[i].getName().toUpperCase())) {
                return businesses[i];
            }
        }
        return null;
    }

    public Review findReview(User user, Business b) {
        for (int i=0; i < businesses.length; i++) {
            if (user.getLogin().equals(this.users[i].getLogin()) && b.getName().equals(this.businesses[i].getName())) {
                return reviews[i];
            }
        }
        return null;
    }

    public void changeReview(Review r, String comment, int rating)  {
        for(int i=0; i < reviews.length; i++) {
            if (r.getComment().equals(reviews[i].getComment()) &&
                    r.getRating()==(reviews[i].getRating())) {
                reviews[i].setComment(comment);
                reviews[i].setRating(rating);
                System.out.println("New:");
                System.out.println(reviews[i].toString());
            }
        }
    }

}
