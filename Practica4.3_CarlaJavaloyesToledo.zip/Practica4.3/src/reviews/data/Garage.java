package reviews.data;

public class Garage extends Business {
    private double priceH;

    public Garage(double priceH) {
        this.priceH = priceH;
    }

    public Garage(String name, String location, double priceH, Review[] reviews) {
        super(name, location, reviews);
        this.priceH = priceH;
    }

    public double getPriceH() {
        return priceH;
    }

    public void setPriceH(double priceH) {
        this.priceH = priceH;
    }

    @Override
    public String toString() {
        return name + '(' + location + ')'+ '-'+ priceH+ "eur/h";
    }
}
