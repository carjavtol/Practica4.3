package reviews.data;

public class Hairdresser extends Business{
    private boolean unisex = false;

    public Hairdresser(boolean unisex) {
        this.unisex = unisex;
    }

    public Hairdresser(String name, String location, boolean unisex, Review[] reviews) {
        super(name, location, reviews);
        this.unisex = unisex;
    }


    public boolean isUnisex() {
        return unisex;
    }

    public void setUnisex(boolean unisex) {
        this.unisex = unisex;
    }

    @Override
    public String toString() {
        return name + '(' + location + ')'+ '-'+ unisex;
    }
}
