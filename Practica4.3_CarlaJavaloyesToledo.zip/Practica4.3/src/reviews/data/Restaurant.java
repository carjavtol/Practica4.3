package reviews.data;

public class Restaurant extends Business {
    private String foodType;

    public Restaurant(String foodType) {
        this.foodType = foodType;
    }

    public Restaurant(String name, String location, String foodType, Review[] reviews) {
        super(name, location, reviews);
        this.foodType = foodType;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    @Override
    public String toString() {
        return name + '(' + location + ')'+ '-'+ foodType;
    }
}
