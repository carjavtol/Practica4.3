package reviews.data;

public class Review {
    protected User associatedUser;
    protected String comment;
    protected int rating;

    public Review(User associatedUser, String comment, int rating) {
        this.associatedUser = associatedUser;
        this.comment = comment;
        this.rating = rating;
    }

    public User getAssociatedUser() {
        return associatedUser;
    }

    public void setAssociatedUser(User associatedUser) {
        this.associatedUser = associatedUser;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return associatedUser.getLogin() +
                comment + rating+ "/5";
    }
}
